import java.io.*;
import java.sql.*;

public class CSVToMySQL {

    private static final String URL = "jdbc:mysql://localhost:3306/aseuropa_java";
    private static final String USER = "root";
    private static final String PASSWORD = "root";

    public static void main(String[] args) {
        String csvFile = "productos.csv";
        leerYGuardarCSV(csvFile);
        listarProductos();
    }

    public static void leerYGuardarCSV(String filePath) {
        String sql = "INSERT INTO productos24 (sku, nombre, precio) VALUES (?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql);
             BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            br.readLine(); // Saltar encabezado
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                stmt.setString(1, data[0]); // SKU
                stmt.setString(2, data[1]); // Nombre
                stmt.setDouble(3, Double.parseDouble(data[2])); // Precio
                stmt.executeUpdate();
            }
            System.out.println("Productos insertados correctamente en productos24.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void listarProductos() {
        String sql = "SELECT sku, nombre, precio FROM productos24";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                System.out.println("SKU: " + rs.getString("sku") + ", Nombre: " + rs.getString("nombre") + ", Precio: " + rs.getDouble("precio"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
